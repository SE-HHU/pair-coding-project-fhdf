package jmain;

import junit.framework.Assert;
import junit.framework.TestCase;

public class MainvoidTest extends TestCase {

	public void testDating() {
		String x = Mainvoid.Dating(3, 9);
		Assert.assertEquals("1/3", x);
		
	}

	public void testInfixToSuffix() {
		String x = Mainvoid.infixToSuffix("1+1");
		Assert.assertEquals("1 1 +", x);
		String y = Mainvoid.infixToSuffix("(1+1)*2");
		Assert.assertEquals("1 1 + 2 *", y);
		String z = Mainvoid.infixToSuffix("1*1");
		Assert.assertEquals("1 1 *", z);
				
	}

	public void testSuffixToArithmetic() {
		String x = Mainvoid.suffixToArithmetic("1 1 +");
		Assert.assertEquals("2", x);
		String y = Mainvoid.suffixToArithmetic("1'2/3 1 +");
		Assert.assertEquals("2'2/3", y);
		String z = Mainvoid.suffixToArithmetic("1'2/3 1 -");
		Assert.assertEquals("2/3", z);
		String j = Mainvoid.suffixToArithmetic("1 4 +");
		Assert.assertEquals("5", j);
		String k = Mainvoid.suffixToArithmetic("1 2 -");
		Assert.assertEquals("-1", k);
		
	}

	public void testCalculate() {
		String x = Mainvoid.calculate("1", "1", "+");
		Assert.assertEquals("2",x);
		String y = Mainvoid.calculate("1", "1/3", "-");
		Assert.assertEquals("2/3",y);
		String z = Mainvoid.calculate("1/3", "1", "-");
		Assert.assertEquals("-2/3",z);
		String j = Mainvoid.calculate("1/3", "1/2", "+");
		Assert.assertEquals("5/6",j);
		String k = Mainvoid.calculate("1'1/3", "1'1/3", "-");
		Assert.assertEquals("0",k);
		String l = Mainvoid.calculate("0", "0", "+");
		Assert.assertEquals("0",l);
		
	}

}
